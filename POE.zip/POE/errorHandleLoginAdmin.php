<?php
//Session initialized
session_start();

//include connection source code.
 include("DBConn.php");

 //Check to see if the user has already logged in. If the user is logged in then redirect them to Workbook Quest home logged in.
 if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true)
 {
    header("location: workbookQuest.php");
    exit;
}

//error count equals to zero.
 $countError = 0;
 //initialize with emty value the newly declared variables.
 $adminUsername_error = $adminPwd_error = "";
 $adminUser = $adminPwd = "";

 //If register.php submit button has been clicked then do the following.
 if(isset($_POST["submitAdminLog"]))
 {
     //If input value of type=name is empty then the following error message will display.
    if(empty($_POST['adminUsername']))
    {
        $adminUsername_error = "Please input the username.";
        $countError++;//error count starts to count.
    }
    else//if it is not empty then $name = type=name. 
    {
        $adminUser = $_POST['adminUsername'];
    }

    if(empty($_POST['adminPwdInput']))
    {
        $adminPwd_error = "Please input the password.";
        $countError++;
    }
    else
    {
        $adminPwd = $_POST['adminPwdInput'];
    }



    if($countError == 0)
    {        
    

     /* //query execution -- first try 
      $dbResult = mysqli_query($connectMyDB, $sql);

      $fetchRow = mysqli_fetch_array($dbResult, MYSQLI_ASSOC);

      $activate = $fetchRow['active'];

      $countResult = mysqli_num_rows($dbResult);*/

     /* if ($dbResult === FALSE) -- different code to try out.
      {
        echo "Error: ". mysqli_error();
      } 
      else 
      { 
        //insert values have succesfully been inserted.
        session_start();
        $_SESSION['message'] = "User has been logged in succesfully.";
        $_SESSION['msg_type'] = "success";
        header('location: workbookQuest.php');
      }*/

      $sql = "SELECT * FROM tbladmins WHERE AdminEmail = '$adminUser' && AdminPassword = '$adminPwd' ";

      //as seen below hashing was tried but was unsuccessful.

      $result = mysqli_query($connectMyDB, $sql);  
      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
      $count = mysqli_num_rows($result);  
        
      if($count == 1){  
          //echo "<h1><center> Login successful </center></h1>";  
         // start_session();
          
          header("location: workbookQuest.php");
      }  
      else{  
          echo "<h1> Login failed. Invalid username or password.</h1>";  
      } 
    

        //closing the connection
        mysqli_close($connectMyDB);
        $connectMyDB = FALSE;
    }
    unset($_POST["submit"]);
 }


 /*if($countError ==0)
    {

      $passCheck = password_hash($pwdInput,PASSWORD_DEFAULT);

      //if(password_verify($pwdInput, $passCheck))
      //{
        $sql = "SELECT UsernameBuyer,BuyerEmail,BuyerPassword FROM tblbuyer WHERE BuyerEmail = '$adminUser' && BuyerPassword ='$adminPwd' ";
    
        $dbResult = mysqli_query($connectMyDB,$sql);
    
        if($dbResult === FALSE)
        {
          echo "Error: ".mysqli_connect_error();
        }
        else
        {
          session_start();
          $_SESSION['message'] ="User has been logged in succesfully.";
          $_SESSION['msg_type']="success";
          header('location:workbookQuest.php');
    
          mysqli_close($connectMyDB);
          $connectMyDB=FALSE;
        
        }
      //}
      //else
      //{
        //$pwdInput = "Error invalid password.";
      //}

     
    unset($_POST["submitAdminLog"]);
      }
    }*/

?>