<?php
 $dbName = "bookstore";
 //$dbName = "demo";
 $server = "localhost";
 $username = "root";
 $pswd = "";

 $connectMyDB = @mysqli_connect($server, $username, $pswd, $dbName);

 if($connectMyDB === FALSE){
     echo "<p>Connection error: " . mysqli_error($connectMyDB) . "</p>";
     @mysqli_close($connectMyDB);
     $connectMyDB = FALSE;
 }else{
  //echo "Successfiul Connection";
 }


?>

