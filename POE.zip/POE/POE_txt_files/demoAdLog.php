<?php

 
//Session initialized
session_start();

//include connection source code.
 include("DBConn.php");

 //Check to see if the user has already logged in. If the user is logged in then redirect them to Workbook Quest home logged in.
 if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true)
 {
    header("location: workbookQuest.php");
    exit;
}

//error count equals to zero.
 $countError = 0;
 //initialize with emty value the newly declared variables.
 $adminUsername_error = $adminPwd_error = "";
 $adminUser = $adminPwd = "";

 //If register.php submit button has been clicked then do the following.
 if(isset($_POST["submitAdminLog"]))
 {
     //If input value of type=name is empty then the following error message will display.
    if(empty($_POST['adminUsername']))
    {
        $adminUsername_error = "Please input the username.";
        $countError++;//error count starts to count.
    }
    else//if it is not empty then $name = type=name. 
    {
        $adminUser = $_POST['adminUsername'];
    }

    if(empty($_POST['adminPwdInput']))
    {
        $adminPwd_error = "Please input the password.";
        $countError++;
    }
    else
    {
        $adminPwd = $_POST['adminPwdInput'];
    }



    if($countError == 0)
    {
     /* $passCheck = password_hash($adminPwd,PASSWORD_DEFAULT);

      if(password_verify($adminPwd, $passCheck))
      {
        $sql = "SELECT UsernameBuyer,BuyerEmail,BuyerPassword FROM tblbuyer WHERE BuyerEmail = '$adminUser' && BuyerPassword ='$adminPwd' ";
    
        $dbResult = mysqli_query($connectMyDB,$sql);
    
        if($dbResult === FALSE)
        {
          echo "Error: ".mysqli_connect_error();
        }
        else
        {
          session_start();
          $_SESSION['message'] ="User has been logged in succesfully.";
          $_SESSION['msg_type']="success";
          header('location:workbookQuest.php');
    
          mysqli_close($connectMyDB);
          $connectMyDB=FALSE;
        
        }
      }
      else
      {
        $adminPwd = "Error invalid password.";
      }*/

      $sql = "SELECT * FROM tblbuyer WHERE BuyerEmail = '$adminUser' && BuyerPassword = '$adminPwd' ";

      $result = mysqli_query($connectMyDB, $sql);  
      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
      $count = mysqli_num_rows($result);  
        
      if($count == 1){  
          //echo "<h1><center> Login successful </center></h1>";  
         // start_session();
          
          header("location: workbookQuest.php");
      }  
      else{  
          echo "<h1> Login failed. Invalid username or password.</h1>";  
      }  

     //closing the connection
     mysqli_close($connectMyDB);
     $connectMyDB = FALSE;
 }
 unset($_POST["submit"]);
}
    /*}
    unset($_POST["submit"]);
 }*/


 /*if($countError ==0)
    {

      $passCheck = password_hash($pwdInput,PASSWORD_DEFAULT);

      //if(password_verify($pwdInput, $passCheck))
      //{
        $sql = "SELECT UsernameBuyer,BuyerEmail,BuyerPassword FROM tblbuyer WHERE BuyerEmail = '$adminUser' && BuyerPassword ='$adminPwd' ";
    
        $dbResult = mysqli_query($connectMyDB,$sql);
    
        if($dbResult === FALSE)
        {
          echo "Error: ".mysqli_connect_error();
        }
        else
        {
          session_start();
          $_SESSION['message'] ="User has been logged in succesfully.";
          $_SESSION['msg_type']="success";
          header('location:workbookQuest.php');
    
          mysqli_close($connectMyDB);
          $connectMyDB=FALSE;
        
        }
      //}
      //else
      //{
        //$pwdInput = "Error invalid password.";
      //}

     
    unset($_POST["submitAdminLog"]);
      }
    }*/

?>



<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="home.php">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" style="color:white;">Register</a></li>
                <li><a href="login.php" class = "active" style="color:rgb(17, 38, 91);">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
        <h1 style="font-size: 40px; color: white; text-align:left; margin-top:200px">Admin Login</h1>
          
       <form action="" method="POST">
            <div class="reg">
                <label for="adminname" class="formLabel">Username</label><br>
                <label for="adminNoteName" class="formLabel">(Email)</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="adminUsername"class="formtext" value="<?php echo $adminUser;?>">
                <span class="formErrorLabel"><?php echo $adminUsername_error; ?></span>
            </div>

            <div class="reg">
                <label for="adminPwd" class="formLabel">Password</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="adminPwdInput"class="formtext" value="<?php echo $adminPwd;?>">
                <span class="formErrorLabel"><?php echo $adminPwd_error; ?></span>
            </div>
        
            <!--button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;-->
            <div class="reg" style = "line-height: 6.6;">
                <button type="submit" name="submitForgotPwd" class="btn" style="margin-left: 180px; height: 50px; width: 200px;">FORGOT PASSWORD</button>
                <button type="submit" name="submitAdminLog" class="btn" style="margin-left: 30px; height: 50px; width: 120px;">LOG IN</button>
            </div>
        </form>

        </div>
       </div>
    </body>
</html>


