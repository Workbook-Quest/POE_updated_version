<?php

include("DBConn.php");

//Notes -- p464!!!!!!!
//Declare the variables
/*$servername = "localhost";
$username = "root";
$password = "";

//establishing connection 
$connectMyDB = mysqli_connect($servername, $username, $password);

//checking connection
if ($connectMyDB === FALSE) 
{
  echo "<p>Failed to connect to MySQL: " . mysqli_connect_error() . "</p>";
  exit();//Do not continue, go out!
}*/



$deleteTable = $nowDelete = $createTable = $nowCreate = "";

//Code to see if Table Exists
$isFound = mysqli_query($connectMyDB, "SELECT * FROM tblbuyer");//(www.learningaboutelectronics.com, n.d.)

if($isFound !== FALSE)//check if statement
{
   echo("The table exist in the database.");//message to user

   //Calls below functions
   //deleteTbl();
   //createOrRecreateTbl();
   //loadTxtFile();

   $deleteTable = 'DROP TABLE tblbuyer';

    $nowDelete = mysqli_query($connectMyDB , $deleteTable);

    if(!$nowDelete)
    {
        echo("<p>Error! The table 'tblbuyer' was not dropped: " . mysqli_error($connectMyDB , $deleteTable) . ".</p>");
    }
    else
    {
        echo("<p>The table 'tblbuyer' was succesfully dropped.</p>");
        //createOrRecreateTbl();

        $createTable = "CREATE TABLE tblbuyer
                    (Username VARCHAR(50) NOT NULL,
                    BuyerName VARCHAR(50)NOT NULL,
                    BuyerSurname VARCHAR(50)NOT NULL,
                    BuyerEmail VARCHAR(50)NOT NULL,
                    BuyerPassword VARCHAR(50)NOT NULL,
                    StudentNumber VARCHAR(50)NOT NULL)";


    $nowCreate = mysqli_query($connectMyDB, $createTable);

    if(!$nowCreate)
    {
        echo("<p>Error! The table 'tblbuyer' was not created: " . mysqli_error($connectMyDB) . ".</p>");
    }
    else
    {
        echo("<p>The table 'tblbuyer' was succesfully created.</p>");
        //loadTxtFile();

        $open = fopen('userData.txt','r');
 
            while (!feof($open)) 
            {
                $getTxtLn = fgets($open);
                $explodeLn = explode(",",$getTxtLn);
                
                list($name,$BuyerName,$BuyerSurname,$BuyerEmail,$BuyerPassword,$StudentNumber) = $explodeLn;

                //$hashing = password_hash($BuyerPassword, PASSWORD_DEFAULT);
                
                $query = "insert into tblbuyer (Username,BuyerName,BuyerSurname,BuyerEmail,BuyerPassword,StudentNumber) 
                values('$name','$BuyerName','$BuyerSurname','$BuyerEmail','$BuyerPassword','$StudentNumber')";
                mysqli_query($connectMyDB,$query);

                
            }
            
            echo"<p>The text file values have been successfully inserted into the table 'tblbuyer'.</p>";

            fclose($open);
    }
    }

    
}
else
{
   echo("The table does not exist in the database.");//message to user
}

//Delete an existing tbl
/*function deleteTbl()
{
    $deleteTable = 'DROP TABLE tblbuyer';

    $nowDelete = mysqli_query($connectMyDB , $deleteTable);

    if(!$nowDelete)
    {
        echo("<p>Error! The table 'tblbuyer' was not dropped: " . mysqli_error($connectMyDB , $deleteTable) . "</p>");
    }
    else
    {
        echo("<p>The table 'tblbuyer' was succesfully dropped</p>");
        createOrRecreateTbl();
    }
}*/

//(Re)create a tbl
/*function createOrRecreateTbl()
{
    $createTable = "CREATE TABLE tblbuyer
                    (Username VARCHAR(50) NOT NULL,
                    BuyerName VARCHAR(50)NOT NULL,
                    BuyerSurname VARCHAR(50)NOT NULL,
                    BuyerEmail VARCHAR(50)NOT NULL,
                    BuyerPassword VARCHAR(50)NOT NULL,
                    StudentNumber VARCHAR(50)NOT NULL)";


    $nowCreate = mysqli_query($connectMyDB, $createTable);

    if(!$nowCreate)
    {
        echo("<p>Error! The table 'tblbuyer' was not created: " . mysqli_error($connectMyDB) . "</p>");
    }
    else
    {
        echo("<p>The table 'tblbuyer' was succesfully created</p>");
        loadTxtFile();
    }
}*/

//Load text file data in database tbl
/*function loadTxtFile()
{
    $loadSql = "LOAD DATA LOCAL INFILE 'C:\wamp64\www\POE' INTO TABLE tblbuyer FIELDS TERMINATED BY ','"; -- Try the demo first!! But its preferred to do this on the cmd console.
}*/

/*
Reference:

www.learningaboutelectronics.com. (n.d.). How to Check if a MySQL Table Exists Using PHP. [online] Available at: http://www.learningaboutelectronics.com/Articles/How-to-check-if-a-MySQL-table-exists-using-PHP.php [Accessed 7 Jun. 2022].

*/

?>
