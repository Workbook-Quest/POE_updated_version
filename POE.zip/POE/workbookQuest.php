<?php

    include("DBConn.php");

?>

<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>

    <div class = "bg-image"><!--w3Schools.com--> <!--img alt src="images/cart.png" style="background:red; width: 2%; height: 2%;"-->
        <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="workbookQuest.php" class = "active">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookListLoggedIn.php">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logOut.php" style = "color: white;">Log Out</a></li>
                <li><a href="cart.php" style="background:red;"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li>
                <!--div class="cart-btn">
                <button><img alt src="imag-->
                <!--div class="cart-btn">es/cart.png" style="background:red; width: 2%; height: 2%;"></button>
                </div-->
            </ul>
        </div>
        
        <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white">Home</h1>

        <div class ="textBox">
        <h2 style="color: #f2f2f2"><!--Has a border-->
            FIND THE BOOKS THAT YOU<br><br>
            WANT TO SELL OR BUY.<br><br>

            <form action="" method="POST">
            <div class="mb-3">
                <input type="text" class="form-control" name="bookTitle" hint="Enter book ISBN"/>
            </div><br>
            <button type="submit" name="search" class="btn">Find book to buy or sell</button>
            </form>
        </h2>
        </div>

        <h1 style="font-size: 40px; color: white">How it works</h1>
          
        <div class = "textBox" style="color: white; text-align: left;">
            <p style="color: white; text-align: left;">STEP 1</p>
            <p style ="text-indent:25px;">LOG IN AND THEN CLICK ON BOOK LIST</p>
            <p style ="text-indent:25px;">(To buy and sell you MUST be a registered user and you MUST be logged in first.)<br><br></p>
            <p style="color: white; text-align: left;">STEP 2</p>
            <p style ="text-indent:25px;">SEARCH FOR YOUR TEXTBOOK</p>
            <p style ="text-indent:25px;">(Enter the books name)<br><br></p>
            <p style="color: white; text-align: left;">STEP 3</p>
            <p style ="text-indent:25px;">LIST YOUR TEXTBOOK</p>
            <p style ="text-indent:25px;">(Choose the book you want to sell/buy.)<br><br></p>
            <p style="color: white; text-align: left;">STEP 4</p>
            <p style ="text-indent:25px;">WAITING</p>
            <p style ="text-indent:25px;">(Wait for the book to get delivered after you have payed for it or wait for it to get bought.)</p>
        </div>

        </div>
       </div>
    </body>
</hmtl>