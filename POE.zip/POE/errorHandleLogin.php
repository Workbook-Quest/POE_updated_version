<?php

session_start();

 include("DBConn.php");

// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: workbookQuest.php");
    exit;
}
 

 $countError = 0;
 $username_error= $pwdInput_error = $stNum_error = "";
 $username = $pwdInput = $stNum = $login_err="";

 if(isset($_POST["logIn"]))
 {
 
  // Check if username is empty
  if(empty($_POST['username']))
  {
      $username_error = "Please enter username.";
      $countError++;
  } 
  else
  {
      $username = $_POST['username'];
  }

  if(empty($_POST['stNumber']))
  {
      $stNum_error = "Please enter your student number.";
      $countError++;
  }
  else
  {
    $stNum = $_POST['stNumber'];
  }
  
  // Check if password is empty
  if(empty($_POST['pwdInput']))
  {
      $pwdInput_error = "Please enter your password.";
      $countError++;
  } 
  else
  {
      $pwdInput = $_POST['pwdInput'];
  }
  //https://www.tutorialrepublic.com/php-tutorial/php-mysql-login-system.php;
 
 /*if(empty($username_error) && empty($pwd_error)){
    // Prepare a select statement
    $sql = "SELECT UsernameBuyer, BuyerPassword FROM tblbuyer WHERE username = ?";
    
    if($stmt = mysqli_prepare($dbconnect, $sql)){
      
      mysqli_stmt_bind_param($stmt, "s", $param_username);
      
      $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                 
                    mysqli_stmt_bind_result($stmt, $username, $hashed_password);

                    if(mysqli_stmt_fetch($stmt)){

                        if(password_verify($pwdInput, $hashed_password)){
                            
                            session_start();

                            $_SESSION["loggedin"] = true;
                            
                            $_SESSION["username"] = $username; 
                            header("location: workbookQuest.php");
                          } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    
      }
    // Close connection
    mysqli_close($dbconnect);*/


    if($countError ==0)
    {

      $passCheck = password_hash($pwdInput,PASSWORD_DEFAULT);

      $sql = "SELECT UsernameBuyer, BuyerEmail, BuyerPassword, StudentNumber FROM tblbuyer WHERE BuyerEmail = '$username' && BuyerPassword ='$pwdInput' &&  StudentNumber = '$stNum' ";
    
    $dbResult = mysqli_query($connectMyDB,$sql);

    if($dbResult === FALSE)
    {
      echo "Error: Could not execute sql statement.".mysqli_connect_error();
    }
    else
    {
      session_start();
      $_SESSION['message'] ="User has been logged in succesfully.";
      $_SESSION['msg_type']="success";
      header('location:workbookQuest.php');

      mysqli_close($connectMyDBt);
      $connectMyDB=FALSE;
    
    }
    unset($_POST["logIn"]);
      }
    }


?>