<?php

    include("DBConn.php");
    include("errorHandleLoginAdmin.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="home.php">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" style="color:white;">Register</a></li>
                <li><a href="login.php" class = "active" style="color:rgb(17, 38, 91);">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
        <h1 style="font-size: 40px; color: white; text-align:left; margin-top:200px">Admin Login</h1>
          
       <form action="" method="POST">
            <div class="reg">
                <label for="adminname" class="formLabel">Username</label><br>
                <label for="adminNoteName" class="formLabel">(Email)</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="adminUsername" class="formtext" value="<?php echo $adminUser;?>">
                <span class="formErrorLabel"><?php echo $adminUsername_error; ?></span>
            </div>

            <div class="reg">
                <label for="adminPwd" class="formLabel">Password</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="adminPwdInput" class="formtext" value="<?php echo $adminPwd;?>">
                <span class="formErrorLabel"><?php echo $adminPwd_error; ?></span>
            </div>
        
            <!--button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;-->
            <div class="reg" style = "line-height: 6.6;">
                <button type="submit" name="submitForgotPwd" class="btn" style="margin-left: 180px; height: 50px; width: 200px;">FORGOT PASSWORD</button>
                <button type="submit" name="submitAdminLog" class="btn" style="margin-left: 30px; height: 50px; width: 120px;">LOG IN</button>
            </div>
        </form>

        </div>
       </div>
    </body>
</html>


